<!DOCTYPE html>
<html>
<head>
	<title>My Blogs</title>
</head>
<style >
	table {
   border: 1px solid black; 
    width: 100%;
 	margin-top: 30px;
    border-collapse: collapse;
}

th, td {
    text-align: center;
    padding: 5px;
}

tr:nth-child(even){
	background-color: #f2f2f2
}
th {
    background-color: #4CAF50;
    color: white;
}
button{
	border-radius: 5px;
    border: none;
    color: white;
    padding: 10px 20px;
    text-align: center;
    font-size: 15px;
}
#edit{
	background-color: #008CBA;
}

#delete{
	background-color: #f44336;
}
</style>
<body>
<div style="overflow-x:auto;">
	<table>
		<thead>
			<th>Author</th>
			<th>Blog Title</th>
			<th>Blog Content</th>
			<th>Options</th>
		</thead>
		<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>

				<td><?php echo e($blog->author); ?></td>	
				<td><?php echo e($blog->blogTitle); ?></td>	
				<td><?php echo e($blog->blogContent); ?></td>
				<td>
					
						<a href="/editBlog/<?php echo e($blog->id); ?>">
								<button id="edit">Edit</button>
						</a>
					
					
						<a href="/deleteBlog/<?php echo e($blog->id); ?>">
								<button id="delete">Delete</button>
						
					
				</td>
			
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>

</body>
</html>