<!DOCTYPE html>
<html>
<head>
	<title>Foro de La Verdad</title>
</head>
<body>
Trending topics
</body>
</html>