<!DOCTYPE html>
<html>
<head>
	<title>Create Your Blog</title>
</head>
<style>
	input[type="text"]{
		width: 500px;
		height: 45px;
		border:  1px solid gray;
		border-radius: 5px;
		margin-left: 150px;
		padding: 10px;
		margin-bottom: 20px;
		font-size: 20px;
	}
	.container{
		width: 800px;
		height: 775px;
		background: rgba(131, 131, 131, 0.5);
		margin: 0 auto;
		margin-top: 20px;
	}
	textarea{
		margin-top: 10px;
		margin-left: 120px;
		border-radius: 5px;
		font-size: 20px;
		padding: 30px;
	}
	#author{
		margin-top: 35px;
	}
	input[type="submit"]{
		width: 150px;
		height: 40px;
		border:  none;
		border-radius: 5px;
		font-size: 20px;
		margin-left: 325px;
		margin-top: 20px;
		background-color: #33c418;
		color: #fff;
	}
	input[type="submit"]:hover{
		background-color: green;
	}
	body{
		background-image: url('img/bg.jpg');
		background-repeat: no-repeat;
	}
</style>
<body>
<form method="POST" action="/addBlog">
{{ csrf_field() }}
<div class="container">
	<div>
		<input type="text" name="author" id="author" placeholder="Author">
	</div>
	<div>
		<input type="text" name="blogTitle" placeholder="Blog Title">
	</div>
	<div>
		<textarea rows="15" cols="45" name="blogContent" placeholder="Enter your content here..."></textarea><br />
	</div>
	<div>
		<input type="submit" name="submit" placeholder="add">
	</div>
</div>

</form>
</body>
</html>