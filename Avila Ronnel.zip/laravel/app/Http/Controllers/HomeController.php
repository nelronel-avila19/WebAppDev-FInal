<?php

namespace App\Http\Controllers;
use App\Blog;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth', ['only' => 'createBlog']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
    public function createBlog()
    {
       return view('create-blog');
    }
     public function addBlog(Request $request)
    {
        $author = $request->author;
        $blogTitle = $request->blogTitle;
        $blogContent = $request->blogContent;
    
        $blog = new Blog;

        $blog->author=$author;
        $blog->blogTitle=$blogTitle;
        $blog->blogContent=$blogContent;
        $blog->save();

        return redirect('/showBlog');
    }
    public function showBlog(Request $request)
    {
        $blogs= Blog::all();
        return view('showBlog', compact('blogs'));
    }
    public function editBlog(Request $request, $id)
    {
        $blog= Blog::find($id);
        return view('/editBlog', compact('blog'));
    }
    public function save(Request $request)
    {   
        $id = $request ->id;
        $author = $request->author;
        $blogTitle = $request->blogTitle;
        $blogContent = $request->blogContent;
    
        $blog = Blog::find($id);

        $blog->id=$id;
        $blog->author=$author;
        $blog->blogTitle=$blogTitle;
        $blog->blogContent=$blogContent;
        $blog->save();
 
        return redirect('/showBlog');
    }
    public function deleteBlog(Request $request, $id)
    {
            $blog = Blog::find($id)->delete();
            return view('/welcome', compact('blog'));
    }
    }
